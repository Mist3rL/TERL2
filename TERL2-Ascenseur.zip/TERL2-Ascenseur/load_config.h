#ifndef LOAD_CONFIG_H
#define LOAD_CONFIG_H

#include <iostream>
#include "loader.class.h"
#include "immeuble.class.h"
#include "ascenseur.class.h"
#include "personne.class.h"
#include <vector>

Uint32 obtenirPixel(SDL_Surface*, int, int);
void loadConfig(SDL_Surface*, Immeuble&, std::vector<Ascenseur>&);

#endif // LOAD_CONFIG_H
