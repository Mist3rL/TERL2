#include "immeuble.class.h"

Immeuble::Immeuble(unsigned int etages)
{
    etagesCount=etages;
    listesEtages=new Etages[etages];
}
Immeuble::~Immeuble()
{
    delete listesEtages;
}
Etages* Immeuble::getListesEtages()
{
    return listesEtages;
}
unsigned int Immeuble::getEtagesCount()
{
    return etagesCount;
}
