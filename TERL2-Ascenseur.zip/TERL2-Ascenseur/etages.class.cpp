#include "etages.class.h"
unsigned int Etages::countEtages=0;
using namespace std;

Etages::Etages()
{
    ++countEtages;
    id=countEtages;
}
Etages::~Etages(){ }
void Etages::addAscenseur(unsigned int id, vector<Ascenseur>& ascenseurs)
{
    listesAscenseurs.push_back(id);
    if (ascenseurs[id-1].getCurrentEtages()==-1) /// Si l'ascenseur n'a toujours pas eu d'�tages attribu�
    {
        ascenseurs[id-1].setCurrentEtages(this->id-1); /// On lui dis qu'il doit se positionner � celui ci au d�part
    }
    ascenseurs[id-1].addEtages(this->id-1);
}
vector<unsigned int> Etages::getListesAscenseurs()
{
    return listesAscenseurs;
}
bool Etages::haveAscenseurAtCols(unsigned int cols, vector<Ascenseur>& ascenseurs) /// Pour la gui...
{
    for (size_t i=0;i<listesAscenseurs.size();i++)
    {
        if (ascenseurs[listesAscenseurs[i]-1].getCols()==cols+1)
            return true;
    }
    return false;
}
