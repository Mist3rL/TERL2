#ifndef MOTEUR_H
#define MOTEUR_H
#include "immeuble.class.h"
#include "loader.class.h"
#include "population.class.h"
#include <math.h>
void bougerAscenseurs(LoaderObject&, std::vector<Ascenseur>&, long, Population&);
void bougerPersonnes(LoaderObject&, Population&, long, std::vector<Ascenseur>&);
#endif // MOTEUR_H
