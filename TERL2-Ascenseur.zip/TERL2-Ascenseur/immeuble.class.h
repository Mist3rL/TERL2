#ifndef IMMEUBLE_CLASS_H
#define IMMEUBLE_CLASS_H

#include "etages.class.h"
class Immeuble{
    private:
        unsigned int etagesCount;
        Etages* listesEtages;
    public:
        Immeuble(unsigned int);
        ~Immeuble();
        Etages* getListesEtages();
        unsigned int getEtagesCount();
};

#endif // IMMEUBLE_CLASS_H
