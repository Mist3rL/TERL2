#ifndef ASCENSEUR_CLASS_H
#define ASCENSEUR_CLASS_H

#include "loader.class.h"
#include "config.h"
#include "personne.class.h"
#include <vector>
enum{NONE, TOP, BOTTOM};
class Ascenseur{
    private:
        static unsigned int countAscenseur;
        unsigned int id;
        unsigned int current_etages;
        unsigned int cols;
        std::vector<unsigned int> personnes;
        std::vector<unsigned int> etages;
        int vitesse;
        int positionY;
        int etagesAim;
        int hadToWait;
    public:
        Ascenseur();
        Ascenseur(unsigned int);
        ~Ascenseur();
        void setCurrentEtages(unsigned int);
        void setCols(unsigned int);
        unsigned int getCurrentEtages();
        unsigned int getCols();
        bool canAcceptPeople();
        void addPersonnes(int);
        unsigned int getNbrPersonnes();
        std::vector<unsigned int> getPersonnes(); /// Renvoi un vecteur des indexs des personnes dans l'ascenseur
        int getVitesse();
        int getPosition();
        void setVitesse(int);
        void setPosition(int);
        int seekEtagesAim(Personne *); /// Algo pour avoir la prochaine destination
        int getEtagesAim(); /// Prochaine destination de l'ascenseur
        void setEtagesAim(int);
        bool getHadToWait(); /// Renvoie true si une/des personne(s) est/sont en mouvement vers le dit ascenseur, sinon false
        void increaseWait();
        void decreaseWait();
        int getDiffEtages(int, int); /// Algo pour voir l'ascenseur + rapide
        void addEtages(unsigned int);
        std::vector<unsigned int> getEtages(); /// Renvoie la liste des �tages que l'ascenseur peut desservir
        void removePersonnes(unsigned int); /// La personne est sortie de l'ascenseur
        int getHadToWaitInt();
};
#endif // ASCENSEUR_CLASS_H
