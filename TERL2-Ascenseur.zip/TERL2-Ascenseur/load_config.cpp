#include "load_config.h"

using namespace std;

Uint32 obtenirPixel(SDL_Surface *surface, int x, int y)
{
    int nbOctetsParPixel = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * nbOctetsParPixel;
    switch(nbOctetsParPixel)
    {
        case 1:
            return *p;
        case 2:
            return *(Uint16 *)p;
        case 3:
            if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
                return p[0] << 16 | p[1] << 8 | p[2];
            else
                return p[0] | p[1] << 8 | p[2] << 16;
        case 4:
            return *(Uint32 *)p;
        default:
            return 0;
    }
}


void loadConfig(SDL_Surface* image, Immeuble& immeuble, vector<Ascenseur>& ascenseurs)
{
    vector<int> cols_used;
    SDL_LockSurface(image);
    Uint32 pixel;
    Uint8 r,v,b;
    for (int y=image->h-1;y>=0;y--)
    {
        for (int x=0;x<image->w;x++)
        {
            pixel=obtenirPixel(image, x, y);
            SDL_GetRGB(pixel, image->format, &r, &v, &b);
            if (r==0 && v==0 && b==0) /// Un ascenseur
            {
                if (!vectorHave(x, cols_used))
                {
                    cols_used.push_back(x);
                    ascenseurs.push_back(x+1);
                }
                immeuble.getListesEtages()[(image->h-1)-y].addAscenseur((x+1), ascenseurs);
            }
        }
    }
    SDL_UnlockSurface(image);
}
