#ifndef DECISION_CLASS_H
#define DECISION_CLASS_H
class Decision{
    private:
        int etages;
        float duree; /// Temps que passe la personne � faire ses courses (secondes)
    public:
        Decision(int, float);
        ~Decision();
        int getEtages();
        float getDuree();
        void setDuree(float);
};
#endif // DECISION_CLASS_H
