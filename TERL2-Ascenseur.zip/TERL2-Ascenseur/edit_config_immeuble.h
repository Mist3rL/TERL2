#ifndef EDIT_CONFIG_IMMEUBLE_H
#define EDIT_CONFIG_IMMEUBLE_H

#include <cstdlib>
#include <iostream>
#include <time.h>
#include "config.h"
#include "loader.class.h"
#include "gui.h"
#include "moteur.h"
#include "population.class.h"
#include "souris.struct.h"
#include "load_config.h"

void editImmeuble(SDL_Surface* image, LoaderObject& surfaces, Immeuble& immeubles, std::vector<Ascenseur>& ascenseurs);

#endif // EDIT_CONFIG_IMMEUBLE_H
