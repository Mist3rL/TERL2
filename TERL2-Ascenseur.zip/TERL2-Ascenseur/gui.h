#ifndef GUI_H
#define GUI_H

#include "loader.class.h"
#include "immeuble.class.h"
#include "ascenseur.class.h"
#include "config.h"
#include "population.class.h"
#include "souris.struct.h"
#include <iostream>
#include <vector>
#include <string>

void afficherImmeuble(LoaderObject&, Immeuble&, std::vector<Ascenseur>&, SDL_Rect, SDL_Surface*, TTF_Font*);
void afficherAscenseurs(LoaderObject&, std::vector<Ascenseur>&, SDL_Rect, sourisTooltip&);
void afficherPersonnes(LoaderObject&, Population&, SDL_Rect, sourisTooltip&, int);
void ecrireHeure(LoaderObject&, long, SDL_Surface*, TTF_Font*, int);
void afficherTooltip(LoaderObject&, Population&, std::vector<Ascenseur>&, SDL_Surface*, TTF_Font*, sourisTooltip&);
void afficherEtagesCount(LoaderObject&, Population&, Immeuble&, SDL_Surface*, TTF_Font*, SDL_Rect);
void afficherBoutons(LoaderObject&, SDL_Surface*, TTF_Font*, sourisTooltip&);

#endif // GUI_H
