#include "decision.class.h"

Decision::Decision(int e, float d)
{
    etages=e;
    duree=d;
}
Decision::~Decision(){ }
int Decision::getEtages(){ return etages; }
float Decision::getDuree(){ return duree; }
void Decision::setDuree(float d) { duree=d; }
