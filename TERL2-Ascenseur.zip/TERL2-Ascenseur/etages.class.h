#ifndef ETAGES_CLASS_H
#define ETAGES_CLASS_H

#include <vector>
#include "ascenseur.class.h"
class Etages{
    private:
        std::vector<unsigned int> listesAscenseurs; /// Listes des ascenseurs dispo � cette �tage
        static unsigned int countEtages;
        unsigned int id;
    public:
        Etages();
        ~Etages();
        void addAscenseur(unsigned int,std::vector<Ascenseur>&);
        void removeAscenseur(unsigned int,std::vector<Ascenseur>&);
        bool haveAscenseurAtCols(unsigned int,std::vector<Ascenseur>&);
        std::vector<unsigned int> getListesAscenseurs();
};

#endif // ETAGES_CLASS_H
