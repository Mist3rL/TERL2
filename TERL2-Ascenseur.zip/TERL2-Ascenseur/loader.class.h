#ifndef LOAD_CLASS_H
#define LOAD_CLASS_H

#include "SDL/include/SDL.h"
#include "SDL/include/SDL_image.h"
#include "SDL/include/SDL_ttf.h"
#include "SDL2_rotozoom.h"
#include "config.h"

enum{ECRAN,VIDE,ASCENSEUR,PERSONNE,ASCENSEUR_REAL,ASCENSEUR_OPEN,TOOLTIP_SCREEN,PERSONNE_HOVER};
class LoaderObject{
    private:
        SDL_Window *window;
        SDL_Surface *ecran;
        SDL_Surface *vide, *vide_const;
        SDL_Surface *ascenseur, *ascenseur_const;
        SDL_Surface *personne, *personne_const;
        SDL_Surface *ascenseur_real, *ascenseur_real_const;
        SDL_Surface *ascenseur_open, *ascenseur_open_const;
        SDL_Surface *texte;
        SDL_Surface *tooltip_screen;
        SDL_Surface *personne_hover, *personne_hover_const;
        TTF_Font *police;
        bool error;
    public:
        LoaderObject(int, int);
        ~LoaderObject();
        SDL_Surface* getSurface(int);
        void setSurface(int, SDL_Surface*);
        TTF_Font* getPolice();
        bool getError();
        SDL_Window* getWindow();
        void scale(double, double);
        void scaleFree();
};
#endif // LOAD_CLASS_H
