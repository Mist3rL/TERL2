#include "souris.struct.h"

void resetSourisTooltip(sourisTooltip& sInfos)
{
    sInfos.onTooltip=false;
    sInfos.isHover=false;
    sInfos.page=1;
    sInfos.personneHover=-1;
    sInfos.personneSelected=-1;
    sInfos.personnesHover.clear();
    sInfos.isHoverPageN=false;
    sInfos.isHoverPageP=false;
    sInfos.isHoverPersInAsc=false;
}
